console.log("page loaded...");

function play(element){
    element.classList.play();
}

function stop(element){
    element.classList.pause();
}