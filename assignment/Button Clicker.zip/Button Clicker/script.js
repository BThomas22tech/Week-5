console.log("linked javascript page")

function Logout(element){
    document.querySelector(".btn").innerText = "Log Out";

}

function hide(element) {
    element.remove();
}